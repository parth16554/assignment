var app = angular.module('assessmentApp', []);
app.controller('assessmentController', function($scope, $http) {
  $http.get("https://ghibliapi.herokuapp.com/films")
  .then(function(response) {
      $scope.response = response.data;
      console.log($scope.response);
  });
  $scope.getDetails = function (index) {
    $scope.movie = $scope.response[index].title;
    $scope.director = $scope.response[index].director;
    $scope.description = $scope.response[index].description;
    $scope.producer = $scope.response[index].producer;
    $scope.release_date = $scope.response[index].release_date;
    $scope.rt_score = $scope.response[index].rt_score;
  };
});